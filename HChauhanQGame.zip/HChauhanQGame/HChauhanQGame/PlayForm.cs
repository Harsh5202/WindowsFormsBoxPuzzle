﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HChauhanQGame
{
    public partial class PlayForm : Form
    {
        private int moveCount = 0; // Tracks the number of moves
        private PictureBox selectedBox = null; // Currently selected box
        private int remainingBoxes = 0; // Tracks the number of remaining boxes

        public PlayForm()
        {
            InitializeComponent();
            InitializeControlPanel();
        }


        private void InitializeControlPanel()
        {

            btnUp.Click += (sender, e) => MoveBox(Direction.Up, txtMoves, txtRemainingBoxes);
            btnDown.Click += (sender, e) => MoveBox(Direction.Down, txtMoves, txtRemainingBoxes);
            btnLeft.Click += (sender, e) => MoveBox(Direction.Left, txtMoves, txtRemainingBoxes);
            btnRight.Click += (sender, e) => MoveBox(Direction.Right, txtMoves, txtRemainingBoxes);
        }


        private void PlayForm_Load(object sender, EventArgs e)
        {

        }

        private void LoadGameLevel(string filePath)
        {
            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    // Read rows and columns
                    if (!int.TryParse(reader.ReadLine(), out int rows) || rows <= 0)
                        throw new InvalidDataException("Invalid row count in level file.");

                    if (!int.TryParse(reader.ReadLine(), out int cols) || cols <= 0)
                        throw new InvalidDataException("Invalid column count in level file.");

                    // Clear existing tiles
                    gamePanel.Controls.Clear();
                    moveCount = 0;
                    remainingBoxes = 0;

                    int tileWidth = gamePanel.Width / cols;
                    int tileHeight = gamePanel.Height / rows;

                    // Read tile data in groups of three lines
                    while (!reader.EndOfStream)
                    {
                        string rowLine = reader.ReadLine();
                        string colLine = reader.ReadLine();
                        string typeLine = reader.ReadLine();

                        if (rowLine == null || colLine == null || typeLine == null)
                            throw new InvalidDataException("Incomplete tile data in level file.");

                        if (!int.TryParse(rowLine, out int row) ||
                            !int.TryParse(colLine, out int col) ||
                            !int.TryParse(typeLine, out int tileType))
                            throw new InvalidDataException("Invalid tile data in level file.");

                        if (!Enum.IsDefined(typeof(ToolType), tileType))
                            throw new InvalidDataException($"Invalid tileType: {tileType}.");

                        // Create and position the tile
                        PictureBox tile = new PictureBox
                        {
                            Width = tileWidth,
                            Height = tileHeight,
                            Location = new Point(col * tileWidth, row * tileHeight),
                            BorderStyle = BorderStyle.FixedSingle,
                            Tag = (ToolType)tileType // Store tool type in Tag
                        };

                        SetTileImage(tile, (ToolType)tileType);

                        // Attach click event only to boxes
                        if ((ToolType)tileType == ToolType.RedBox || (ToolType)tileType == ToolType.GreenBox)
                        {
                            remainingBoxes++;
                            tile.Click += Box_Click; // Attach the Box_Click event handler
                        }

                        gamePanel.Controls.Add(tile);
                    }

                    // Update scores
                    txtRemainingBoxes.Text = remainingBoxes.ToString();
                    txtMoves.Text = moveCount.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading game file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void SetTileImage(PictureBox tile, ToolType tool)
        {
            switch (tool)
            {
                case ToolType.None:
                    tile.Image = null;
                    break;
                case ToolType.Wall:
                    tile.Image = Properties.Resources.Wall;
                    break;
                case ToolType.RedDoor:
                    tile.Image = Properties.Resources.red_door;
                    break;
                case ToolType.GreenDoor:
                    tile.Image = Properties.Resources.green_door;
                    break;
                case ToolType.RedBox:
                    tile.Image = Properties.Resources.Red_Box;
                    break;
                case ToolType.GreenBox:
                    tile.Image = Properties.Resources.greenbox;
                    break;
            }

            tile.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void Box_Click(object sender, EventArgs e)
        {
            if (sender is PictureBox box && ((ToolType)box.Tag == ToolType.RedBox || (ToolType)box.Tag == ToolType.GreenBox))
            {
                selectedBox = box; // Set the selected box
                MessageBox.Show("Box selected! Use the controller to move it.", "Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }



        private void MoveBox(Direction direction, TextBox txtMoves, TextBox txtRemainingBoxes)
        {
            if (selectedBox == null)
            {
                MessageBox.Show("No box selected! Please click on a box to select it.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Point newPosition = selectedBox.Location;

            while (true) // Continue moving until hitting an obstacle
            {
                // Calculate the new position based on direction
                switch (direction)
                {
                    case Direction.Up:
                        newPosition.Y -= selectedBox.Height;
                        break;
                    case Direction.Down:
                        newPosition.Y += selectedBox.Height;
                        break;
                    case Direction.Left:
                        newPosition.X -= selectedBox.Width;
                        break;
                    case Direction.Right:
                        newPosition.X += selectedBox.Width;
                        break;
                }

                // Check if the new position is valid
                if (!IsValidMove(newPosition, out PictureBox obstacle))
                {
                    // Stop movement if invalid
                    break;
                }

                // Move the box to the new position
                selectedBox.Location = newPosition;
                selectedBox.BringToFront(); // Ensure visibility

                // Handle door collision and merging
                if (obstacle != null)
                {
                    ToolType boxTool = (ToolType)selectedBox.Tag;
                    ToolType doorTool = (ToolType)obstacle.Tag;

                    // If matching door, allow merge (exit)
                    if ((boxTool == ToolType.RedBox && doorTool == ToolType.RedDoor) ||
                        (boxTool == ToolType.GreenBox && doorTool == ToolType.GreenDoor))
                    {
                        gamePanel.Controls.Remove(selectedBox); // Remove the box
                        remainingBoxes--; // Update remaining box count
                        txtRemainingBoxes.Text = remainingBoxes.ToString();
                        MessageBox.Show("Box exited through the matching door!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }

                    // If mismatched door, stop the box
                    if ((boxTool == ToolType.RedBox && doorTool == ToolType.GreenDoor) ||
                        (boxTool == ToolType.GreenBox && doorTool == ToolType.RedDoor))
                    {
                        break; // Stop the box
                    }
                }
            }

            // Increment the move count
            moveCount++;
            txtMoves.Text = moveCount.ToString();

            // Check if all boxes are removed
            if (remainingBoxes == 0)
            {
                MessageBox.Show("Congratulations! You completed the level!", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetGame(txtMoves, txtRemainingBoxes);
            }
        }

        private bool IsValidMove(Point position, out PictureBox obstacle)
        {
            obstacle = null;

            // Ensure the move is within the bounds of the game panel
            if (position.X < 0 || position.Y < 0 ||
                position.X + selectedBox.Width > gamePanel.Width ||
                position.Y + selectedBox.Height > gamePanel.Height)
                return false;

            // Check for collisions with other controls in the panel
            foreach (Control control in gamePanel.Controls)
            {
                if (control is PictureBox tile && tile.Bounds.IntersectsWith(new Rectangle(position, selectedBox.Size)))
                {
                    ToolType tileTool = (ToolType)tile.Tag;

                    // If it's a wall or another box, stop movement
                    if (tileTool == ToolType.Wall || tileTool == ToolType.RedBox || tileTool == ToolType.GreenBox)
                    {
                        obstacle = tile;
                        return false; // Block movement
                    }

                    // Allow door handling in `MoveBox`
                    if (tileTool == ToolType.RedDoor || tileTool == ToolType.GreenDoor)
                    {
                        obstacle = tile;
                        return true; // Return true to handle merging or stopping in `MoveBox`
                    }
                }
            }

            return true; // Valid move
        }



        private void ResetGame(TextBox txtMoves, TextBox txtRemainingBoxes)
        {
            gamePanel.Controls.Clear();
            moveCount = 0;
            remainingBoxes = 0;
            txtMoves.Text = "0";
            txtRemainingBoxes.Text = "0";
            selectedBox = null;
        }
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        enum Direction
        {
            Up,
            Down,
            Left,
            Right
        }

        private void loadGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "QGame files (*.qgame)|*.qgame|All files (*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                LoadGameLevel(openFileDialog1.FileName);
            }
        }
        public enum ToolType
        {
            None = 0,
            Wall = 1,
            RedDoor = 2,
            GreenDoor = 3,
            RedBox = 6,
            GreenBox = 7
        }

        private void btnUp_Click(object sender, EventArgs e)
        {

        }

        private void btnRight_Click(object sender, EventArgs e)
        {

        }

    }
}


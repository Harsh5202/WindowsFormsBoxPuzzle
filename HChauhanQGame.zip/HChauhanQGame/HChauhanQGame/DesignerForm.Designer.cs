﻿namespace HChauhanQGame
{
    partial class DesignerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DesignerForm));
            this.pnlToolBox = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.pbRedDoor = new System.Windows.Forms.PictureBox();
            this.pbGreenDoor = new System.Windows.Forms.PictureBox();
            this.pbRedBox = new System.Windows.Forms.PictureBox();
            this.pbGreenBox = new System.Windows.Forms.PictureBox();
            this.pbNone = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pbWall = new System.Windows.Forms.PictureBox();
            this.btnGreenBox = new System.Windows.Forms.Button();
            this.btnRedBox = new System.Windows.Forms.Button();
            this.btnGreenDoor = new System.Windows.Forms.Button();
            this.btnRedDoor = new System.Windows.Forms.Button();
            this.btnWall = new System.Windows.Forms.Button();
            this.btnNone = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtRows = new System.Windows.Forms.TextBox();
            this.txtColumns = new System.Windows.Forms.TextBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.pnlGrid = new System.Windows.Forms.Panel();
            this.pnlToolBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbRedDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGreenDoor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRedBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGreenBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWall)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlToolBox
            // 
            this.pnlToolBox.Controls.Add(this.label9);
            this.pnlToolBox.Controls.Add(this.pbRedDoor);
            this.pnlToolBox.Controls.Add(this.pbGreenDoor);
            this.pnlToolBox.Controls.Add(this.pbRedBox);
            this.pnlToolBox.Controls.Add(this.pbGreenBox);
            this.pnlToolBox.Controls.Add(this.pbNone);
            this.pnlToolBox.Controls.Add(this.label6);
            this.pnlToolBox.Controls.Add(this.label5);
            this.pnlToolBox.Controls.Add(this.label4);
            this.pnlToolBox.Controls.Add(this.label3);
            this.pnlToolBox.Controls.Add(this.label2);
            this.pnlToolBox.Controls.Add(this.label1);
            this.pnlToolBox.Controls.Add(this.pbWall);
            this.pnlToolBox.Controls.Add(this.btnGreenBox);
            this.pnlToolBox.Controls.Add(this.btnRedBox);
            this.pnlToolBox.Controls.Add(this.btnGreenDoor);
            this.pnlToolBox.Controls.Add(this.btnRedDoor);
            this.pnlToolBox.Controls.Add(this.btnWall);
            this.pnlToolBox.Controls.Add(this.btnNone);
            this.pnlToolBox.Location = new System.Drawing.Point(0, 90);
            this.pnlToolBox.Name = "pnlToolBox";
            this.pnlToolBox.Size = new System.Drawing.Size(211, 658);
            this.pnlToolBox.TabIndex = 0;
            this.pnlToolBox.Paint += new System.Windows.Forms.PaintEventHandler(this.ToolButton_Paint);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(73, 4);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "ToolBox";
            // 
            // pbRedDoor
            // 
            this.pbRedDoor.ImageLocation = "C:\\Users\\harsh\\source\\repos\\HChauhanQGame\\HChauhanQGame\\Resources\\red door.jpg";
            this.pbRedDoor.Location = new System.Drawing.Point(11, 219);
            this.pbRedDoor.Name = "pbRedDoor";
            this.pbRedDoor.Size = new System.Drawing.Size(82, 67);
            this.pbRedDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbRedDoor.TabIndex = 2;
            this.pbRedDoor.TabStop = false;
            // 
            // pbGreenDoor
            // 
            this.pbGreenDoor.ImageLocation = "C:\\Users\\harsh\\source\\repos\\HChauhanQGame\\HChauhanQGame\\Resources\\green door.jpg";
            this.pbGreenDoor.Location = new System.Drawing.Point(11, 318);
            this.pbGreenDoor.Name = "pbGreenDoor";
            this.pbGreenDoor.Size = new System.Drawing.Size(82, 67);
            this.pbGreenDoor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbGreenDoor.TabIndex = 3;
            this.pbGreenDoor.TabStop = false;
            // 
            // pbRedBox
            // 
            this.pbRedBox.ImageLocation = "C:\\Users\\harsh\\source\\repos\\HChauhanQGame\\HChauhanQGame\\Resources\\Red Box.jpg";
            this.pbRedBox.Location = new System.Drawing.Point(11, 416);
            this.pbRedBox.Name = "pbRedBox";
            this.pbRedBox.Size = new System.Drawing.Size(82, 67);
            this.pbRedBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbRedBox.TabIndex = 4;
            this.pbRedBox.TabStop = false;
            // 
            // pbGreenBox
            // 
            this.pbGreenBox.ImageLocation = "C:\\Users\\harsh\\source\\repos\\HChauhanQGame\\HChauhanQGame\\Resources\\greenbox.jpg";
            this.pbGreenBox.Location = new System.Drawing.Point(11, 521);
            this.pbGreenBox.Name = "pbGreenBox";
            this.pbGreenBox.Size = new System.Drawing.Size(82, 67);
            this.pbGreenBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbGreenBox.TabIndex = 5;
            this.pbGreenBox.TabStop = false;
            // 
            // pbNone
            // 
            this.pbNone.ImageLocation = "C:\\Users\\harsh\\source\\repos\\HChauhanQGame\\HChauhanQGame\\Resources\\None.jpg";
            this.pbNone.Location = new System.Drawing.Point(11, 23);
            this.pbNone.Name = "pbNone";
            this.pbNone.Size = new System.Drawing.Size(82, 67);
            this.pbNone.TabIndex = 1;
            this.pbNone.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(113, 546);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "Green Box";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(113, 441);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Red Box";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(113, 343);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "Green Door";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(113, 244);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Red Door";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(113, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Wall";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(113, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "None";
            // 
            // pbWall
            // 
            this.pbWall.ImageLocation = "C:\\Users\\harsh\\source\\repos\\HChauhanQGame\\HChauhanQGame\\Resources\\Wall.jpg";
            this.pbWall.Location = new System.Drawing.Point(11, 119);
            this.pbWall.Name = "pbWall";
            this.pbWall.Size = new System.Drawing.Size(82, 67);
            this.pbWall.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbWall.TabIndex = 1;
            this.pbWall.TabStop = false;
            // 
            // btnGreenBox
            // 
            this.btnGreenBox.Location = new System.Drawing.Point(11, 521);
            this.btnGreenBox.Name = "btnGreenBox";
            this.btnGreenBox.Size = new System.Drawing.Size(183, 67);
            this.btnGreenBox.TabIndex = 6;
            this.btnGreenBox.UseVisualStyleBackColor = true;
            this.btnGreenBox.Click += new System.EventHandler(this.ToolButton_Click);
            // 
            // btnRedBox
            // 
            this.btnRedBox.Location = new System.Drawing.Point(11, 416);
            this.btnRedBox.Name = "btnRedBox";
            this.btnRedBox.Size = new System.Drawing.Size(183, 67);
            this.btnRedBox.TabIndex = 5;
            this.btnRedBox.UseVisualStyleBackColor = true;
            this.btnRedBox.Click += new System.EventHandler(this.ToolButton_Click);
            // 
            // btnGreenDoor
            // 
            this.btnGreenDoor.Location = new System.Drawing.Point(11, 318);
            this.btnGreenDoor.Name = "btnGreenDoor";
            this.btnGreenDoor.Size = new System.Drawing.Size(183, 67);
            this.btnGreenDoor.TabIndex = 4;
            this.btnGreenDoor.UseVisualStyleBackColor = true;
            this.btnGreenDoor.Click += new System.EventHandler(this.ToolButton_Click);
            // 
            // btnRedDoor
            // 
            this.btnRedDoor.Location = new System.Drawing.Point(11, 219);
            this.btnRedDoor.Name = "btnRedDoor";
            this.btnRedDoor.Size = new System.Drawing.Size(183, 67);
            this.btnRedDoor.TabIndex = 3;
            this.btnRedDoor.UseVisualStyleBackColor = true;
            this.btnRedDoor.Click += new System.EventHandler(this.ToolButton_Click);
            // 
            // btnWall
            // 
            this.btnWall.Location = new System.Drawing.Point(11, 119);
            this.btnWall.Name = "btnWall";
            this.btnWall.Size = new System.Drawing.Size(183, 67);
            this.btnWall.TabIndex = 2;
            this.btnWall.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnWall.UseVisualStyleBackColor = true;
            this.btnWall.Click += new System.EventHandler(this.ToolButton_Click);
            // 
            // btnNone
            // 
            this.btnNone.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.btnNone.Location = new System.Drawing.Point(11, 23);
            this.btnNone.Name = "btnNone";
            this.btnNone.Size = new System.Drawing.Size(183, 67);
            this.btnNone.TabIndex = 1;
            this.btnNone.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnNone.UseVisualStyleBackColor = false;
            this.btnNone.Click += new System.EventHandler(this.btnNone_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1217, 30);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(128, 26);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(128, 26);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 16);
            this.label7.TabIndex = 3;
            this.label7.Text = "Rows:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(340, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 16);
            this.label8.TabIndex = 4;
            this.label8.Text = "Columns:";
            // 
            // txtRows
            // 
            this.txtRows.Location = new System.Drawing.Point(95, 49);
            this.txtRows.Name = "txtRows";
            this.txtRows.Size = new System.Drawing.Size(219, 22);
            this.txtRows.TabIndex = 5;
            this.txtRows.TextChanged += new System.EventHandler(this.txtRows_TextChanged);
            // 
            // txtColumns
            // 
            this.txtColumns.Location = new System.Drawing.Point(426, 49);
            this.txtColumns.Name = "txtColumns";
            this.txtColumns.Size = new System.Drawing.Size(219, 22);
            this.txtColumns.TabIndex = 6;
            // 
            // btnGenerate
            // 
            this.btnGenerate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnGenerate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerate.Location = new System.Drawing.Point(728, 43);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(197, 35);
            this.btnGenerate.TabIndex = 7;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = false;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // pnlGrid
            // 
            this.pnlGrid.Location = new System.Drawing.Point(217, 90);
            this.pnlGrid.Name = "pnlGrid";
            this.pnlGrid.Size = new System.Drawing.Size(988, 658);
            this.pnlGrid.TabIndex = 9;
            this.pnlGrid.Paint += new System.Windows.Forms.PaintEventHandler(this.ToolButton_Paint);
            // 
            // DesignerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1217, 778);
            this.Controls.Add(this.pnlGrid);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.txtColumns);
            this.Controls.Add(this.txtRows);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pnlToolBox);
            this.Name = "DesignerForm";
            this.Text = "DesignerForm";
            this.pnlToolBox.ResumeLayout(false);
            this.pnlToolBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbRedDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGreenDoor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRedBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGreenBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbWall)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlToolBox;
        private System.Windows.Forms.Button btnGreenBox;
        private System.Windows.Forms.Button btnRedBox;
        private System.Windows.Forms.Button btnGreenDoor;
        private System.Windows.Forms.Button btnRedDoor;
        private System.Windows.Forms.Button btnWall;
        private System.Windows.Forms.Button btnNone;
        private System.Windows.Forms.PictureBox pbWall;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbRedDoor;
        private System.Windows.Forms.PictureBox pbGreenDoor;
        private System.Windows.Forms.PictureBox pbRedBox;
        private System.Windows.Forms.PictureBox pbGreenBox;
        private System.Windows.Forms.PictureBox pbNone;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtRows;
        private System.Windows.Forms.TextBox txtColumns;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel pnlGrid;
    }
}
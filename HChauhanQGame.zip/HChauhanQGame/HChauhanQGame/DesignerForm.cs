﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HChauhanQGame
{
    // Enum to define the different types of tools that can be selected in the game
    public enum ToolType { None, Wall, RedDoor, GreenDoor, RedBox, GreenBox }


    public partial class DesignerForm : Form
    {
        // Fields to track the current selected tool and image
        private ToolType currentTool = ToolType.None;
        private Image selectedToolImage;
        private int cellSize = 50;

        // Field to indicate whether a grid has already been generated
        private bool isGridGenerated = false;

        // Constructor to initialize the form and set up the toolbox
        public DesignerForm()
        {
            InitializeComponent();
            InitializeToolbox();
        }

        // Method to initialize toolbox items and associate images with each tool
        private void InitializeToolbox()
        {
            // Setting the Tag property of each button with the ToolType and associated Image
            
            btnNone.Tag = new ToolDetails { ToolType = ToolType.None, Image = null };
            btnWall.Tag = new ToolDetails { ToolType = ToolType.Wall, Image = Properties.Resources.Wall };
            btnRedDoor.Tag = new ToolDetails { ToolType = ToolType.RedDoor, Image = Properties.Resources.red_door };
            btnGreenDoor.Tag = new ToolDetails { ToolType = ToolType.GreenDoor, Image = Properties.Resources.green_door };
            btnRedBox.Tag = new ToolDetails { ToolType = ToolType.RedBox, Image = Properties.Resources.Red_Box };
            btnGreenBox.Tag = new ToolDetails { ToolType = ToolType.GreenBox, Image = Properties.Resources.greenbox };

          
        }
        // Event handler for clicking the "None" button
        // Sets the current tool to "None", which is used to clear cell images in the grid
        private void btnNone_Click(object sender, EventArgs e)
        {
            currentTool = ToolType.None;
            selectedToolImage = null;
        }
        // Event handler for clicking any tool button (e.g., Wall, Red Door)
        // Updates the currentTool and selectedToolImage based on the clicked button
        private void ToolButton_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (button != null)
            {
                ToolDetails details = button.Tag as ToolDetails;
                if (details != null)
                {
                    currentTool = details.ToolType;
                    selectedToolImage = details.Image;
                }
            }
        }
        // Event handler for generating the grid based on input row and column counts
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            
            // Validate input for rows and columns
            bool isRowInt = int.TryParse(txtRows.Text, out int rows);
            bool isColumnInt = int.TryParse(txtColumns.Text, out int columns);

            // Check if a grid already exists and prompt the user if so
            if (isGridGenerated)
            {
                DialogResult result = MessageBox.Show("Do you want to create a new level? If you do, the current level will be lost.",
                                                      "Confirm New Level", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.No)
                {
                    // User chose not to create a new level, so return without generating
                    return;
                }
            }

            // Check if inputs are valid positive integers
            if (!isRowInt || rows <= 0 || !isColumnInt || columns <= 0)
            {
                MessageBox.Show("Please provide valid data for rows and columns (Both must be positive integers)!",
                                "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Generate the grid with the specified number of rows and columns
            GenerateGrid(rows, columns);
            isGridGenerated = true; // Mark that a grid has been generated
        }



        // Event handler for saving the grid layout to a file
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveDialog = new SaveFileDialog())
            {
                saveDialog.FileName = "level1.qgame";
                saveDialog.Filter = "QGame files (*.qgame)|*.qgame|All files (*.*)|*.*";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    int wallCount = 0, doorCount = 0, boxCount = 0;

                    // Save the grid to the file and count items
                    SaveGridToFile(saveDialog.FileName, ref wallCount, ref doorCount, ref boxCount);

                    // Display a summary message
                    MessageBox.Show($"File saved successfully:\n" +
                                    $"Walls: {wallCount}\n" +
                                    $"Doors: {doorCount}\n" +
                                    $"Boxes: {boxCount}",
                                    "Save Summary", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }



        // Method to generate the grid of PictureBox cells based on specified rows and columns
        private void GenerateGrid(int rows, int columns)
        {
            pnlGrid.Controls.Clear();
            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < columns; col++)
                {
                    PictureBox cell = new PictureBox
                    {
                        BorderStyle = BorderStyle.FixedSingle,
                        Width = cellSize,
                        Height = cellSize,
                        SizeMode = PictureBoxSizeMode.StretchImage,
                        Location = new Point(col * cellSize, row * cellSize),
                        BackColor = Color.White,
                        Tag = ToolType.None
                    };
                    cell.Click += Cell_Click;
                    pnlGrid.Controls.Add(cell);
                }
            }
        }


        // Event handler for cell clicks - applies or clears tool images based on the currentTool
        private void Cell_Click(object sender, EventArgs e)
        {
            PictureBox cell = sender as PictureBox;
            if (cell != null)
            {
                if (currentTool == ToolType.None)
                {
                    // If "None" is selected, clear the image from the clicked cell
                    cell.Image = null;           // Remove the image from the cell
                    cell.Tag = ToolType.None;    // Reset the tool type to None
                }
                else
                {
                    // If another tool is selected, apply the selected tool image and tag
                    cell.Image = selectedToolImage;
                    cell.Tag = currentTool;
                }
            }
        }
        private void txtRows_TextChanged(object sender, EventArgs e)
        {

        }

        // Method to save the grid layout to a file and count different item types
        private void SaveGridToFile(string fileName, ref int wallCount, ref int doorCount, ref int boxCount)
        {
            using (StreamWriter sw = new StreamWriter(fileName))
            {
                // Write the number of rows and columns
                int rows = pnlGrid.Height / cellSize;
                int cols = pnlGrid.Width / cellSize;
                sw.WriteLine(rows);
                sw.WriteLine(cols);

                foreach (Control c in pnlGrid.Controls)
                {
                    if (c is PictureBox pb && pb.Tag != null)
                    {
                        ToolType tool = (ToolType)pb.Tag;

                        // Count the items based on the tool type
                        switch (tool)
                        {
                            case ToolType.Wall:
                                wallCount++;
                                break;
                            case ToolType.RedDoor:
                            case ToolType.GreenDoor:
                                doorCount++;
                                break;
                            case ToolType.RedBox:
                            case ToolType.GreenBox:
                                boxCount++;
                                break;
                        }

                        // Calculate the row and column of the PictureBox
                        int row = pb.Location.Y / cellSize;
                        int col = pb.Location.X / cellSize;

                        // Write the tool information to the file in the specified format
                        sw.WriteLine(row);    // Row index
                        sw.WriteLine(col);    // Column index
                        sw.WriteLine((int)tool); // ToolType as integer
                    }
                }
            }
        }

        // Class to store tool details (ToolType and Image) for each tool button
        public class ToolDetails
        {

            public ToolType ToolType { get; set; }
            public Image Image { get; set; }
        }

        public enum ToolType { None, Wall, RedDoor, GreenDoor, RedBox, GreenBox }

        private void ToolButton_Paint(object sender, PaintEventArgs e)
        {

        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
 